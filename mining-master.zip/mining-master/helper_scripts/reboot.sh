shutdown -r now
